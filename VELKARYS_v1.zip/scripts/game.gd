extends Node2D

const SAVE_PATH := "user://velkarys_save.json"
enum Screen { TITLE, MENU, CLASS_SELECT, GAME }
var screen: Screen = Screen.TITLE
var chosen_class := "Guerreiro"
var player_pos := Vector2(2100, 1500)
var player_speed := 300.0
var player_name := "Ren"
var has_save := false
var touch_dir := Vector2.ZERO
var adventurer_open := false
var status_open := false
var status_tab := "Totais"
var player_level := 1
var player_xp := 0
var player_xp_next := 100
var player_gold := 0
var free_attribute_points := 20
# Oito atributos distribuíveis: HP, Mana, ATK, DEF, MATK, MDEF, EVA e LUK.
var pending_attributes := {"HP": 0, "Mana": 0, "ATK": 0, "DEF": 0, "MATK": 0, "MDEF": 0, "EVA": 0, "LUK": 0}
var base_attributes := {"HP": 100, "Mana": 60, "ATK": 10, "DEF": 5, "MATK": 8, "MDEF": 4, "EVA": 3, "LUK": 1}
var spent_attributes := {"HP": 0, "Mana": 0, "ATK": 0, "DEF": 0, "MATK": 0, "MDEF": 0, "EVA": 0, "LUK": 0}
var ui: CanvasLayer
var message := ""
var message_time := 0.0
var world_time := 0.0
const MOBILE_SCALE := Vector2(800.0 / 960.0, 360.0 / 600.0)
const WORLD_SIZE := Vector2(4200.0, 3000.0)
const WATER_MARGIN := 90.0

func _ready() -> void:
    get_window().title = "VELKARYS — Mundo Aberto"
    get_window().size = Vector2i(800, 360)
    scale = MOBILE_SCALE
    _check_save()
    _build_ui()
    queue_redraw()

func _check_save() -> void:
    has_save = FileAccess.file_exists(SAVE_PATH)

func _clear_ui() -> void:
    if is_instance_valid(ui):
        ui.queue_free()
    ui = CanvasLayer.new()
    ui.scale = MOBILE_SCALE
    add_child(ui)

func _build_ui() -> void:
    _clear_ui()
    match screen:
        Screen.TITLE:
            _build_title()
        Screen.MENU:
            _build_menu()
        Screen.CLASS_SELECT:
            _build_class_select()
        Screen.GAME:
            _build_game_ui()

func _panel(parent: Node, pos: Vector2, size: Vector2) -> PanelContainer:
    var p := PanelContainer.new()
    p.position = pos
    p.custom_minimum_size = size
    p.add_theme_stylebox_override("panel", _style(Color("#081a36"), Color("#35aaff"), 3))
    parent.add_child(p)
    return p

func _style(bg: Color, border: Color, width: int = 2) -> StyleBoxFlat:
    var st := StyleBoxFlat.new()
    st.bg_color = bg
    st.border_color = border
    st.set_border_width_all(width)
    st.set_corner_radius_all(8)
    st.content_margin_left = 14
    st.content_margin_right = 14
    st.content_margin_top = 8
    st.content_margin_bottom = 8
    return st

func _label(parent: Node, text: String, size: int, color: Color = Color("#e8f5ff")) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    parent.add_child(l)
    return l

func _button(parent: Node, text: String, callback: Callable, size: Vector2 = Vector2(260, 52)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = size
    b.add_theme_font_size_override("font_size", 20)
    b.add_theme_color_override("font_color", Color("#eff8ff"))
    b.add_theme_stylebox_override("normal", _style(Color("#252a35"), Color("#ffb51b"), 3))
    b.add_theme_stylebox_override("hover", _style(Color("#3b4352"), Color("#ffd34f"), 3))
    b.add_theme_stylebox_override("pressed", _style(Color("#111722"), Color("#ff7d18"), 3))
    b.pressed.connect(callback)
    parent.add_child(b)
    return b

func _build_title() -> void:
    var box := VBoxContainer.new()
    box.position = Vector2(300, 105)
    box.custom_minimum_size = Vector2(360, 350)
    box.add_theme_constant_override("separation", 18)
    ui.add_child(box)
    var title := _label(box, "VELKARYS", 48, Color("#ffffff"))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var sub := _label(box, "MUNDO ABERTO", 22, Color("#80cfff"))
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var spacer := Control.new()
    spacer.custom_minimum_size.y = 30
    box.add_child(spacer)
    _button(box, "JOGAR", func(): _go(Screen.MENU))
    _button(box, "SAIR", func(): get_tree().quit())

func _build_menu() -> void:
    var box := VBoxContainer.new()
    box.position = Vector2(220, 70)
    box.custom_minimum_size = Vector2(460, 430)
    box.add_theme_constant_override("separation", 12)
    ui.add_child(box)
    var title := _label(box, "VELKARYS", 34, Color("#ffffff"))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 10)
    box.add_child(tabs)
    _button(tabs, "AVENTURA", func(): _show_menu_area(box, true), Vector2(220, 44))
    _button(tabs, "ROTEIRO & INFORMAÇÕES", func(): _show_menu_area(box, false), Vector2(220, 44))
    _show_menu_area(box, true)

func _show_menu_area(box: VBoxContainer, adventure: bool) -> void:
    for child in box.get_children():
        if child.get_meta("menu_area_content", false):
            child.queue_free()
    var content := VBoxContainer.new()
    content.set_meta("menu_area_content", true)
    content.add_theme_constant_override("separation", 12)
    box.add_child(content)
    if adventure:
        var sub := _label(content, "MUNDO ABERTO", 18, Color("#a7dfff"))
        sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        var cont := _button(content, "CONTINUAR", _continue_game)
        cont.disabled = not has_save
        _button(content, "NOVO JOGO", func(): _go(Screen.CLASS_SELECT))
        _button(content, "VOLTAR", func(): _go(Screen.TITLE), Vector2(160, 42))
    else:
        var heading := _label(content, "O MUNDO DE VELKARYS", 22, Color("#e7c779"))
        heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _label(content, "Explora florestas antigas, caminhos esquecidos e regiões cheias de segredos. Escolhe uma classe, percorre o mapa e acompanha a barra XP para veres o progresso até ao próximo nível.", 16, Color("#e5edf2"))
        _button(content, "COMEÇAR A AVENTURA", func(): _go(Screen.CLASS_SELECT))
        _button(content, "VOLTAR", func(): _show_menu_area(box, true), Vector2(160, 42))

func _build_class_select() -> void:
    var box := VBoxContainer.new()
    box.position = Vector2(240, 90)
    box.custom_minimum_size = Vector2(480, 420)
    box.add_theme_constant_override("separation", 13)
    ui.add_child(box)
    var title := _label(box, "ESCOLHA SUA CLASSE", 30)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var hint := _label(box, "Cada classe define o estilo do seu personagem.", 16, Color("#a9d8ff"))
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var picker := OptionButton.new()
    picker.add_item("Guerreiro — resistente e equilibrado")
    picker.add_item("Mago — poder arcano")
    picker.add_item("Arqueiro — ágil e preciso")
    picker.add_theme_font_size_override("font_size", 17)
    picker.custom_minimum_size = Vector2(450, 48)
    box.add_child(picker)
    picker.item_selected.connect(func(index: int):
        chosen_class = ["Guerreiro", "Mago", "Arqueiro"][index]
    )
    var spacer := Control.new()
    spacer.custom_minimum_size.y = 12
    box.add_child(spacer)
    _button(box, "EXPLORAR MUNDO", _start_new_game, Vector2(450, 58))
    _button(box, "VOLTAR", func(): _go(Screen.MENU), Vector2(180, 42))

func _build_game_ui() -> void:
    _build_status_hud()
    var coords := _label(ui, "X: %d  Y: %d" % [roundi(player_pos.x), roundi(player_pos.y)], 12, Color("#ffffff"))
    coords.position = Vector2(760, 12)
    coords.size = Vector2(180, 24)
    # PNGs fornecidas: o fundo preto faz parte da arte e é preservado.
    # Botões ficam ao lado direito do HUD, sem cobrir retrato, nomes ou valores.
    _png_button("adventurer", Vector2(286, 12), Vector2(48, 48), _open_adventurer_menu)
    _png_button("settings", Vector2(338, 12), Vector2(48, 48), _open_settings)

    # Direcional com as PNGs de setas; mantenha pressionado para caminhar.
    # Direcional organizado: quatro botões exatamente do mesmo tamanho.
    var move_size := Vector2(64, 64)
    # Controles mais baixos e maiores, alinhados numa cruz uniforme.
    _touch_button("up", Vector2(82, 448), move_size, Vector2.UP)
    _touch_button("left", Vector2(18, 512), move_size, Vector2.LEFT)
    _touch_button("down", Vector2(82, 512), move_size, Vector2.DOWN)
    _touch_button("right", Vector2(146, 512), move_size, Vector2.RIGHT)
    # Ataque e interação têm exatamente o mesmo tamanho dos direcionais.
    var action_size := Vector2(64, 64)
    _png_button("attack", Vector2(812, 512), action_size, func(): _show_message("Ataque!"))
    _png_button("interact", Vector2(884, 512), action_size, func(): _show_message("Você observa a região ao redor."))
    if status_open:
        _build_status_menu()
    elif adventurer_open:
        _build_adventurer_menu()
    if message_time > 0:
        var msg := _panel(ui, Vector2(300, 500), Vector2(420, 42))
        _label(msg, message, 14)

func _open_adventurer_menu() -> void:
    adventurer_open = true
    _build_ui()

func _build_adventurer_menu() -> void:
    # Menu centralizado usando a imagem PNG completa de cada botão (ícone + moldura + nome).
    var shade := ColorRect.new()
    shade.position = Vector2(155, 72)
    shade.size = Vector2(650, 456)
    shade.color = Color(0.015, 0.025, 0.05, 0.97)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    ui.add_child(shade)

    var title := _label(ui, "MENU DO AVENTUREIRO", 20, Color("#ffbd35"))
    title.position = Vector2(315, 88)
    title.size = Vector2(330, 30)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    var close := _button(ui, "X", func():
        adventurer_open = false
        _build_ui()
    , Vector2(38, 34))
    close.position = Vector2(750, 82)

    var entries := [
        ["status_menu", "Status"], ["inventory_menu", "Inventário"],
        ["skills_menu", "Habilidades"], ["essence_menu", "Essência"],
        ["missions_menu", "Missão"], ["story_menu", "História"],
        ["bestiary_menu", "Bestiário"]
    ]
    # PNGs completas em tamanho uniforme; três colunas e a sétima opção centralizada.
    var positions := [
        Vector2(220, 132), Vector2(410, 132), Vector2(600, 132),
        Vector2(220, 265), Vector2(410, 265), Vector2(600, 265),
        Vector2(410, 395)
    ]
    for i in range(entries.size()):
        var item: Array = entries[i]
        _menu_image_button(str(item[0]), str(item[1]), positions[i], func():
            if str(item[1]) == "Status":
                status_open = true
                status_tab = "Totais"
            else:
                message = str(item[1]) + " — em desenvolvimento"
                message_time = 2.0
                adventurer_open = false
            _build_ui()
        )

func _build_status_menu() -> void:
    var shade := ColorRect.new()
    shade.position = Vector2(110, 54)
    shade.size = Vector2(740, 500)
    shade.color = Color(0.025, 0.055, 0.095, 0.98)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    ui.add_child(shade)

    var frame := _panel(ui, Vector2(110, 54), Vector2(740, 500))
    frame.add_theme_stylebox_override("panel", _style(Color("#102536"), Color("#d2b46f"), 3))
    var title := _label(ui, "STATUS DO PERSONAGEM", 22, Color("#e5c77b"))
    title.position = Vector2(140, 68)
    title.size = Vector2(570, 32)
    var close := _button(ui, "X", func():
        status_open = false
        _build_ui()
    , Vector2(40, 34))
    close.position = Vector2(790, 62)

    var totals := _button(ui, "TOTAIS", func():
        status_tab = "Totais"
        _build_ui()
    , Vector2(180, 40))
    totals.position = Vector2(145, 110)
    var increase := _button(ui, "AUMENTAR ATRIBUTOS", func():
        status_tab = "Aumentar"
        _build_ui()
    , Vector2(230, 40))
    increase.position = Vector2(335, 110)

    if status_tab == "Totais":
        _label_at(ui, "NV  %d / 50" % player_level, Vector2(150, 165), 16, Color("#f2f5f7"))
        _label_at(ui, "XP  %d / %d" % [player_xp, player_xp_next], Vector2(370, 165), 16, Color("#9cde87"))
        _label_at(ui, "OURO  %d" % player_gold, Vector2(610, 165), 16, Color("#e5c77b"))
        var xpbar := ProgressBar.new()
        xpbar.position = Vector2(150, 194)
        xpbar.size = Vector2(640, 14)
        xpbar.max_value = player_xp_next
        xpbar.value = player_xp
        xpbar.show_percentage = false
        xpbar.add_theme_stylebox_override("background", _style(Color("#172d3a"), Color("#385467"), 1))
        var xpfill := StyleBoxFlat.new()
        xpfill.bg_color = Color("#8bce76")
        xpfill.set_corner_radius_all(4)
        xpbar.add_theme_stylebox_override("fill", xpfill)
        ui.add_child(xpbar)
        var keys := ["HP", "Mana", "ATK", "DEF", "MATK", "MDEF", "EVA", "LUK"]
        var labels := ["Vida (HP)", "Mana (MP)", "Ataque físico (ATK)", "Defesa física (DEF)", "Ataque mágico (MATK)", "Defesa mágica (MDEF)", "Evasão (EVA)", "Sorte (LUK)"]
        for i in range(keys.size()):
            var key: String = keys[i]
            var x := 150.0 + float(i % 2) * 330.0
            var y := 228.0 + float(i / 2) * 48.0
            var multiplier := 10 if key == "HP" else (5 if key == "Mana" else 1)
            var value := int(base_attributes[key]) + int(spent_attributes[key]) * multiplier
            _label_at(ui, labels[i], Vector2(x, y), 14, Color("#b7c9d4"))
            _label_at(ui, str(value), Vector2(x + 240, y), 17, Color("#e5c77b"))
    else:
        _label_at(ui, "Pontos disponíveis: %d" % free_attribute_points, Vector2(150, 165), 17, Color("#e5c77b"))
        _label_at(ui, "Escolhe + e - e confirma para aplicar os pontos.", Vector2(150, 193), 13, Color("#b7c9d4"))
        var keys := ["HP", "Mana", "ATK", "DEF", "MATK", "MDEF", "EVA", "LUK"]
        var labels := ["Vida (HP)", "Mana (MP)", "Ataque físico (ATK)", "Defesa física (DEF)", "Ataque mágico (MATK)", "Defesa mágica (MDEF)", "Evasão (EVA)", "Sorte (LUK)"]
        for i in range(keys.size()):
            var key: String = keys[i]
            var x := 150.0 + float(i % 2) * 330.0
            var y := 230.0 + float(i / 2) * 48.0
            _label_at(ui, "%s  (+%d)" % [labels[i], int(pending_attributes[key])], Vector2(x, y), 13, Color("#e8f1f5"))
            var minus := _button(ui, "−", Callable(self, "_change_pending_attribute").bind(key, -1), Vector2(36, 30))
            minus.position = Vector2(x + 222, y - 5)
            minus.disabled = int(pending_attributes[key]) <= 0
            var plus := _button(ui, "+", Callable(self, "_change_pending_attribute").bind(key, 1), Vector2(36, 30))
            plus.position = Vector2(x + 262, y - 5)
            plus.disabled = free_attribute_points <= 0
        var confirm := _button(ui, "CONFIRMAR ATRIBUTOS", _confirm_attributes, Vector2(280, 42))
        confirm.position = Vector2(340, 485)
        confirm.disabled = _pending_attribute_total() <= 0

func _label_at(parent: Node, text: String, pos: Vector2, size: int, color: Color) -> Label:
    var l := _label(parent, text, size, color)
    l.position = pos
    return l

func _pending_attribute_total() -> int:
    var total := 0
    for key in pending_attributes.keys():
        total += int(pending_attributes[key])
    return total

func _change_pending_attribute(key: String, amount: int) -> void:
    if amount > 0 and free_attribute_points <= 0:
        return
    if amount < 0 and int(pending_attributes[key]) <= 0:
        return
    pending_attributes[key] = int(pending_attributes[key]) + amount
    free_attribute_points -= amount
    _build_ui()

func _confirm_attributes() -> void:
    for key in pending_attributes.keys():
        spent_attributes[key] = int(spent_attributes[key]) + int(pending_attributes[key])
        pending_attributes[key] = 0
    status_tab = "Totais"
    _build_ui()

func _asset_path(asset_name: String) -> String:
    # Assets organizados por função dentro de assets/ui.
    if asset_name in ["up", "down", "left", "right", "attack", "interact"]:
        return "res://assets/ui/Movimentacao/%s.png" % asset_name
    if asset_name in ["skills_icon", "skills_menu"]:
        return "res://assets/ui/Habilidades/%s.png" % asset_name
    if asset_name in ["adventurer", "settings", "status_icon", "essence_icon", "missions_icon", "story_icon", "bestiary_icon", "inventory_icon", "status_menu", "inventory_menu", "essence_menu", "missions_menu", "story_menu", "bestiary_menu"]:
        return "res://assets/ui/Menu_do_aventureiro/%s.png" % asset_name
    return "res://assets/ui/%s.png" % asset_name

func _menu_image_button(asset_name: String, label_text: String, pos: Vector2, callback: Callable) -> void:
    var tex := load(_asset_path(asset_name)) as Texture2D
    if tex == null:
        push_warning("PNG do menu não encontrada: " + asset_name)
        return
    var b := TextureButton.new()
    b.position = pos
    b.size = Vector2(150, 125)
    b.custom_minimum_size = b.size
    b.ignore_texture_size = true
    b.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
    b.texture_normal = tex
    b.texture_hover = tex
    b.texture_pressed = tex
    b.tooltip_text = label_text
    b.pressed.connect(callback)
    ui.add_child(b)

func _png_button(asset_name: String, pos: Vector2, size: Vector2, callback: Callable) -> TextureButton:
    var b := TextureButton.new()
    b.position = pos
    b.custom_minimum_size = size
    b.size = size
    b.ignore_texture_size = true
    b.stretch_mode = TextureButton.STRETCH_SCALE
    var tex := load(_asset_path(asset_name)) as Texture2D
    b.texture_normal = tex
    b.texture_hover = tex
    b.texture_pressed = tex
    b.pressed.connect(callback)
    ui.add_child(b)
    return b

func _touch_button(asset_name: String, pos: Vector2, size: Vector2, direction: Vector2) -> void:
    var b := _png_button(asset_name, pos, size, func(): pass)
    b.button_down.connect(func(): touch_dir = direction)
    b.button_up.connect(func(): touch_dir = Vector2.ZERO)

func _open_settings() -> void:
    var panel := _panel(ui, Vector2(500, 75), Vector2(285, 150))
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 8)
    panel.add_child(col)
    _label(col, "CONFIGURAÇÕES", 16)
    _button(col, "SALVAR JOGO", _save_game, Vector2(235, 38))
    _button(col, "FECHAR", func(): _build_ui(), Vector2(235, 34))

func _show_message(text: String) -> void:
    message = text
    message_time = 2.5
    _build_ui()

func _build_status_hud() -> void:
    # Painel de status com barras visuais, números e cores próprias por atributo.
    var panel := PanelContainer.new()
    panel.position = Vector2(12, 12)
    panel.custom_minimum_size = Vector2(270, 84)
    panel.add_theme_stylebox_override("panel", _style(Color("#07172d"), Color("#53bfff"), 2))
    ui.add_child(panel)
    var outer := VBoxContainer.new()
    outer.add_theme_constant_override("separation", 1)
    panel.add_child(outer)

    var heading := HBoxContainer.new()
    outer.add_child(heading)
    var portrait := PanelContainer.new()
    portrait.custom_minimum_size = Vector2(34, 25)
    portrait.add_theme_stylebox_override("panel", _style(Color("#18395b"), Color("#8bd8ff"), 2))
    heading.add_child(portrait)
    var face := _label(portrait, "R", 27, Color("#ffffff"))
    face.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    face.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    var info := VBoxContainer.new()
    info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    heading.add_child(info)
    _label(info, "%s  •  Lv. 1" % player_name, 13, Color("#ffffff"))
    _label(info, chosen_class, 10, Color("#a9d8ff"))

    _status_bar(outer, "HP", 100, 100, Color("#ff5268"), "♥")
    _status_bar(outer, "MANA", 60, 60, Color("#39c9ff"), "✦")
    _status_bar(outer, "EXP", 0, 100, Color("#8bdf63"), "★")

func _status_bar(parent: Node, title: String, current: int, maximum: int, bar_color: Color, symbol: String) -> void:
    var row := VBoxContainer.new()
    row.add_theme_constant_override("separation", 1)
    parent.add_child(row)
    var line := HBoxContainer.new()
    row.add_child(line)
    var name_label := _label(line, "%s %s" % [symbol, title], 10, bar_color)
    name_label.custom_minimum_size.x = 112
    var value := _label(line, "%d / %d" % [current, maximum], 10, Color("#eff8ff"))
    value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(0, 5)
    bar.min_value = 0
    bar.max_value = maximum
    bar.value = current
    bar.show_percentage = false
    bar.add_theme_stylebox_override("background", _style(Color("#142b45"), Color("#274967"), 1))
    var fill := StyleBoxFlat.new()
    fill.bg_color = bar_color
    fill.set_corner_radius_all(4)
    bar.add_theme_stylebox_override("fill", fill)
    row.add_child(bar)

func _go(next_screen: Screen) -> void:
    screen = next_screen
    _build_ui()
    queue_redraw()

func _start_new_game() -> void:
    player_pos = Vector2(2100, 1500)
    player_level = 1
    player_xp = 0
    player_xp_next = 100
    player_gold = 0
    free_attribute_points = 20
    for key in pending_attributes.keys():
        pending_attributes[key] = 0
        spent_attributes[key] = 0
    message = "O mundo de Velkarys está aberto para você, %s!" % player_name
    message_time = 4.0
    screen = Screen.GAME
    _save_game()
    _build_ui()
    queue_redraw()

func _continue_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    var data = JSON.parse_string(f.get_as_text())
    if data is Dictionary:
        player_pos = Vector2(float(data.get("x", 2100)), float(data.get("y", 1500)))
        chosen_class = str(data.get("class", "Guerreiro"))
        player_level = int(data.get("level", 1))
        player_xp = int(data.get("xp", 0))
        player_xp_next = int(data.get("xp_next", 100 + (player_level - 1) * 25))
        player_gold = int(data.get("gold", 0))
        free_attribute_points = int(data.get("attribute_points", max(0, 20 + (player_level - 1) * 5)))
        if data.has("spent_attributes") and data["spent_attributes"] is Dictionary:
            for key in spent_attributes.keys():
                spent_attributes[key] = int(data["spent_attributes"].get(key, 0))
    screen = Screen.GAME
    message = "Partida carregada!"
    message_time = 3.0
    _build_ui()
    queue_redraw()

func _gain_xp(amount: int) -> void:
    if amount <= 0 or player_level >= 50:
        return
    player_xp += amount
    var leveled_up := false
    while player_xp >= player_xp_next and player_level < 50:
        player_xp -= player_xp_next
        player_level += 1
        free_attribute_points += 5
        player_xp_next = 100 + (player_level - 1) * 25
        leveled_up = true
    if player_level >= 50:
        player_xp = mini(player_xp, player_xp_next)
    message = "Nível aumentado! +5 pontos de atributo." if leveled_up else "+%d XP" % amount
    message_time = 3.0
    _save_game()
    _build_ui()

func _save_game() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    f.store_string(JSON.stringify({"x": player_pos.x, "y": player_pos.y, "class": chosen_class, "level": player_level, "xp": player_xp, "xp_next": player_xp_next, "gold": player_gold, "attribute_points": free_attribute_points, "spent_attributes": spent_attributes}))
    has_save = true
    message = "Jogo salvo!"
    message_time = 3.0
    _build_ui()

func _process(delta: float) -> void:
    if screen != Screen.GAME:
        return
    var dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down") + touch_dir
    if Input.is_key_pressed(KEY_A): dir.x -= 1.0
    if Input.is_key_pressed(KEY_D): dir.x += 1.0
    if Input.is_key_pressed(KEY_W): dir.y -= 1.0
    if Input.is_key_pressed(KEY_S): dir.y += 1.0
    if dir.length() > 1.0:
        dir = dir.normalized()
    player_pos += dir.normalized() * player_speed * delta if dir.length() > 0.001 else Vector2.ZERO
    player_pos.x = clampf(player_pos.x, WATER_MARGIN + 24.0, WORLD_SIZE.x - WATER_MARGIN - 24.0)
    player_pos.y = clampf(player_pos.y, WATER_MARGIN + 24.0, WORLD_SIZE.y - WATER_MARGIN - 24.0)
    if message_time > 0:
        message_time -= delta
        if message_time <= 0:
            _build_ui()
    if Input.is_action_just_pressed("ui_accept"):
        message = "Explore Velkarys livremente!"
        message_time = 3.0
        _build_ui()
    queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
    if screen == Screen.GAME and event is InputEventKey and event.pressed and event.keycode == KEY_E:
        message = "Você observa a região ao redor."
        message_time = 3.0
        _build_ui()

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, Vector2(960, 600)), Color("#07152d"))
    if screen == Screen.TITLE:
        _draw_title_bg()
    elif screen == Screen.MENU:
        _draw_menu_bg()
    elif screen == Screen.CLASS_SELECT:
        _draw_class_bg()
    else:
        _draw_open_world()

func _draw_title_bg() -> void:
    draw_rect(Rect2(0, 0, 960, 600), Color("#183b6a"))
    for i in range(16):
        var x := float((i * 79) % 960)
        draw_circle(Vector2(x, 75 + (i % 4) * 24), 2, Color("#a9dcff"))
    draw_rect(Rect2(0, 430, 960, 170), Color("#254e35"))
    draw_line(Vector2(0, 470), Vector2(960, 400), Color("#b99b63"), 34)
    for i in range(18):
        var x := float((i * 71 + 20) % 960)
        draw_circle(Vector2(x, 430 + (i % 3) * 35), 18, Color("#28633a"))
    draw_string(ThemeDB.fallback_font, Vector2(30, 565), "VELKARYS • ECLIPSE ARCANO", HORIZONTAL_ALIGNMENT_LEFT, 400, 16, Color("#d9f1ff"))

func _draw_menu_bg() -> void:
    draw_rect(Rect2(0, 0, 960, 600), Color("#061329"))
    draw_rect(Rect2(0, 270, 960, 330), Color("#142844"))
    draw_rect(Rect2(100, 180, 760, 230), Color("#0c203b"))
    for i in range(8):
        draw_line(Vector2(0, 470 + i * 18), Vector2(960, 470 + i * 18), Color("#203b5b"), 1)

func _draw_class_bg() -> void:
    draw_rect(Rect2(0, 0, 960, 600), Color("#0c2545"))
    draw_rect(Rect2(80, 70, 800, 460), Color("#12345a"))
    for i in range(5):
        draw_rect(Rect2(120 + i * 145, 120, 95, 125), Color("#7bb7d6"))
        draw_rect(Rect2(127 + i * 145, 127, 81, 110), Color("#bde8f5"))
    draw_rect(Rect2(80, 390, 800, 140), Color("#76583f"))

func _draw_open_world() -> void:
    # Mundo ampliado com água contínua nas extremidades; a câmera acompanha o jogador.
    draw_set_transform(Vector2(480, 300) - player_pos)
    draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#328db9"))
    # Costa de areia e grande área de terra explorável.
    draw_rect(Rect2(WATER_MARGIN - 14, WATER_MARGIN - 14, WORLD_SIZE.x - 2 * (WATER_MARGIN - 14), WORLD_SIZE.y - 2 * (WATER_MARGIN - 14)), Color("#c5ab76"))
    draw_rect(Rect2(WATER_MARGIN, WATER_MARGIN, WORLD_SIZE.x - 2 * WATER_MARGIN, WORLD_SIZE.y - 2 * WATER_MARGIN), Color("#477d43"))
    # Detalhes de grama fixos por todo o mapa.
    for i in range(1500):
        var x := float((i * 83 + 17) % int(WORLD_SIZE.x - WATER_MARGIN * 2) + int(WATER_MARGIN))
        var y := float((i * 47 + 29) % int(WORLD_SIZE.y - WATER_MARGIN * 2) + int(WATER_MARGIN))
        draw_circle(Vector2(x, y), 2.5, Color("#5b914c"))
    # Estradas e um rio interior atravessam a região.
    draw_line(Vector2(WATER_MARGIN, 1420), Vector2(WORLD_SIZE.x - WATER_MARGIN, 980), Color("#9b8155"), 54)
    draw_line(Vector2(WATER_MARGIN, 1420), Vector2(WORLD_SIZE.x - WATER_MARGIN, 980), Color("#c2a16b"), 38)
    draw_line(Vector2(2050, WATER_MARGIN), Vector2(2320, WORLD_SIZE.y - WATER_MARGIN), Color("#9b8155"), 44)
    draw_line(Vector2(2050, WATER_MARGIN), Vector2(2320, WORLD_SIZE.y - WATER_MARGIN), Color("#c2a16b"), 28)
    draw_line(Vector2(WATER_MARGIN, 420), Vector2(WORLD_SIZE.x - WATER_MARGIN, 620), Color("#b9a477"), 72)
    draw_line(Vector2(WATER_MARGIN, 420), Vector2(WORLD_SIZE.x - WATER_MARGIN, 620), Color("#398bb5"), 52)
    # Árvores e arbustos espalhados, evitando costa e estradas.
    for i in range(170):
        var x := float((i * 137 + 135) % int(WORLD_SIZE.x - WATER_MARGIN * 2 - 60) + int(WATER_MARGIN + 30))
        var y := float((i * 97 + 155) % int(WORLD_SIZE.y - WATER_MARGIN * 2 - 60) + int(WATER_MARGIN + 30))
        if abs(y - (420.0 + (x - WATER_MARGIN) * 0.0667)) > 62 and abs(y - (1420.0 - (x - WATER_MARGIN) * 0.1467)) > 48 and abs(x - (2050.0 + y * 0.09)) > 48:
            draw_circle(Vector2(x, y + 7), 17, Color("#3b5835"))
            draw_circle(Vector2(x, y - 8), 19, Color("#245b35"))
            draw_circle(Vector2(x - 6, y - 13), 10, Color("#367742"))
    # Estrutura distante para servir de ponto de referência.
    draw_rect(Rect2(3220, 480, 150, 95), Color("#777b70"))
    draw_rect(Rect2(3240, 460, 22, 120), Color("#9a9d8c"))
    draw_rect(Rect2(3285, 455, 22, 125), Color("#9a9d8c"))
    draw_rect(Rect2(3330, 465, 22, 115), Color("#9a9d8c"))
    draw_rect(Rect2(3228, 465, 135, 16), Color("#b1b2a0"))
    _draw_student(player_pos, Color("#1b2e4f"), true)
    draw_string(ThemeDB.fallback_font, player_pos + Vector2(-28, -27), player_name, HORIZONTAL_ALIGNMENT_LEFT, 100, 13, Color("#ffffff"))
    draw_set_transform(Vector2.ZERO)

func _draw_student(pos: Vector2, uniform: Color, is_player: bool = false) -> void:
    draw_circle(pos + Vector2(0, 2), 14, Color("#29452b"))
    draw_rect(Rect2(pos.x - 7, pos.y - 13, 14, 13), Color("#f0c9a8"))
    draw_rect(Rect2(pos.x - 9, pos.y - 17, 18, 9), Color("#17233a"))
    draw_rect(Rect2(pos.x - 10, pos.y, 20, 22), uniform)
    draw_rect(Rect2(pos.x - 8, pos.y + 20, 6, 8), Color("#182239"))
    draw_rect(Rect2(pos.x + 2, pos.y + 20, 6, 8), Color("#182239"))
    if is_player:
        draw_rect(Rect2(pos.x - 15, pos.y - 23, 30, 3), Color("#46d6ff"))

func _draw_sakura(x: float, y: float) -> void:
    draw_rect(Rect2(x - 5, y, 10, 270), Color("#503b3b"))
    for i in range(20):
        var px := x + float((i * 37) % 130) - 65
        var py := y + float((i * 53) % 120) - 60
        draw_circle(Vector2(px, py), 17, Color("#ed9ecb"))
        draw_circle(Vector2(px + 5, py - 4), 8, Color("#ffd2e8"))
